def move_forward():
    # Assuming the drone is using ArduPilot
    # Send a simple MAV_CMD_NAV_WAYPOINT command to move forward
    vehicle.mav.mission_item_send(
        vehicle.target_system, vehicle.target_component,
        0,  # Sequence
        mavutil.mavlink.MAV_FRAME_GLOBAL_RELATIVE_ALT,
        mavutil.mavlink.MAV_CMD_NAV_WAYPOINT,
        0,  # Current WP
        0,  # Autocontinue
        0,  # Param 1 (acceptance radius, in meters)
        0,  # Param 2 (0: absolute, 1: relative)
        0,  # Param 3 (0: hold time in seconds)
        0,  # Param 4 (yaw angle)
        vehicle.location.global_frame.lat + 0.0001,  # Target latitude (move forward)
        vehicle.location.global_frame.lon,  # Target longitude
        vehicle.location.global_frame.alt  # Target altitude
    )
