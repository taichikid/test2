
import serial, time
import struct
import numpy as np

def receive_serial_data(serial_port, baud_rate, start_byte, num_bytes):
    # シリアルポートを開く
    ser = serial.Serial(serial_port, baud_rate)
    print("【接続成功！】")


    try:
        # スタートビットが一致するまで読み捨てる
        while True:
            if ser.read() == start_byte:
                break

        hex_data_array = []

        # スタートビットと一致した位置から指定したバイト数だけデータを受信
        raw_data = ser.read(num_bytes)
        hex_data = [format(byte, '02X') for byte in raw_data]
        hex_data_array.append(hex_data)

        Start_angle_0 = "00000"
        End_angle_0 = "00000"

        print(hex_data)
        Speed = int(hex_data[2] + hex_data[1], 16)
        Start_angle_x = int(hex_data[4] + hex_data[3], 16)
        End_angle_x = int(hex_data[2] + hex_data[1], 16)
        
        Start_angle = Start_angle_0.replace("00000", str(Start_angle_x))
        End_angle = End_angle_0.replace("00000", str(End_angle_x))
        print(str(End_angle_x))

        # 距離データ取得
        data_num = 12
        Distance = [[0, 0] for _ in range(data_num)]
        
        for i in range(1, 12):
            Distance[i-1][0] = int(hex_data[3*i + 3] + hex_data[3*i + 2], 16)
            Distance[i-1][1] = int(hex_data[3*i + 4], 16)




        return [Speed, int(Start_angle), int(End_angle), Distance]

    finally:
        # シリアルポートを閉じる
        ser.close()

# 以下は使用例です。適切なシリアルポート名やボーレート、スタートビット、受信するバイト数を指定してください。
serial_port_name = "COM3"  # 例: "COM1" or "/dev/ttyUSB0"
baud_rate = 230400
start_byte = b'\x54'  # スタートビットに合わせて変更
num_bytes_to_receive = 50  # 受信するバイト数

received_data = receive_serial_data(serial_port_name, baud_rate, start_byte, num_bytes_to_receive)
print(f'測定速度: {received_data[0]} [θ/s]')
print(f'開始角度: {received_data[1]/100} [θ]')
print(f'終了角度: {received_data[2]/100} [θ]')
Distance = ((received_data[3])[1])[0]
print(f'距離: {Distance} [mm]')