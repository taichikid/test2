from dronekit import connect, VehicleMode
import time

# ドローンが水平になるまで待機
while not vehicle.is_level():
    time.sleep(1)

# 高度を測定
altitude = vehicle.location.global_relative_frame.alt

# 2mとの誤差を計算
error = abs(altitude - 2)

# 誤差を表示
print("2mとの誤差：", error, "m")

# ドローンをホバリングさせる
vehicle.mode = VehicleMode("GUIDED")
