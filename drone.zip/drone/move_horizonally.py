from dronekit import connect, VehicleMode, LocationGlobalRelative
import math
import time

# 前進する距離と速度を設定
target_distance = 10  # 前進する目標距離（10m）
speed = 5  # 前進する速度（m/s）

# 前進するための目標位置を計算
current_location = vehicle.location.global_relative_frame
dNorth = target_distance * math.cos(math.radians(current_location.lat))
dEast = target_distance * math.sin(math.radians(current_location.lat))
target_location = LocationGlobalRelative(current_location.lat + dNorth, current_location.lon + dEast, current_location.alt)

# 目標位置に向かって前進する
vehicle.simple_goto(target_location, groundspeed=speed)

# 前進中の処理
while True:
    remaining_distance = target_distance - vehicle.location.global_relative_frame.distance_to(target_location)
    if remaining_distance <= 0.1:  # 目標距離まで残り0.1m以下になったら
        print("目標距離に到達しました")
        break
    time.sleep(1)

# ドローンをホバリングさせる
vehicle.mode = VehicleMode("GUIDED")
