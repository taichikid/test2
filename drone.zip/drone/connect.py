from dronekit import connect, VehicleMode, LocationGlobalRelative

# ドローンに接続
connection_string = '/dev/ttyACM0'  # ドローンに接続するポートを指定
vehicle = connect(connection_string, wait_ready=True)

# ドローンとの接続を閉じる
vehicle.close()
