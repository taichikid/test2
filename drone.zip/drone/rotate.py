from dronekit import connect, VehicleMode
import time

# 左右に回転する速度を設定
rotation_speed = 30  # 回転する速度（度/秒）

# 左に回転する指示を出す
vehicle.simple_goto(vehicle.location.global_relative_frame, groundspeed=-rotation_speed)
time.sleep(1)  # 1秒間回転させる

# 右に回転する指示を出す
vehicle.simple_goto(vehicle.location.global_relative_frame, groundspeed=rotation_speed)
time.sleep(1)  # 1秒間回転させる

# ドローンをホバリングさせる
vehicle.mode = VehicleMode("GUIDED")
