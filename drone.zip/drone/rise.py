from dronekit import connect, VehicleMode, LocationGlobalRelative

# 上昇する高さを設定
target_altitude = 2  # 上昇する目標高度（2m）

# アームし、離陸する
vehicle.mode = VehicleMode("GUIDED")  # GUIDEDモードに設定
vehicle.armed = True  # アーム
vehicle.simple_takeoff(target_altitude)  # 離陸

# 上昇中の処理
while True:
    current_altitude = vehicle.location.global_relative_frame.alt  # 現在の高度を取得
    if current_altitude >= target_altitude * 0.95:  # 目標高度の95%以上に到達したら
        print("目標高度に到達しました")
        break

# ドローンを降下させる
vehicle.mode = VehicleMode("LAND")  # LANDモードに設定
