import math
from rplidar import RPLidar

def get_obstacle_distance():
    # Connect to the RPLiDAR device
    lidar = RPLidar('/dev/ttyUSB0')  # Replace with the correct port

    try:
        # Start scanning
        lidar.start_motor()
        lidar.start_scan()

        # Read RPLiDAR data
        data = [0] * 360
        for i, scan in enumerate(lidar.iter_scans()):
            for (_, angle, distance) in scan:
                data[int(angle)] = distance

            # Break after the first complete scan
            if i > 0:
                break

        # Calculate the minimum distance (ignoring invalid readings)
        valid_data = [d for d in data if 0 < d < 3000]  # Filter out invalid readings
        min_distance = min(valid_data) if valid_data else float('inf')

        return min_distance

    finally:
        # Stop scanning and disconnect from the RPLiDAR device
        lidar.stop_scan()
        lidar.stop_motor()
        lidar.disconnect()

# Example usage
obstacle_distance = get_obstacle_distance()
print("Obstacle distance: {} meters".format(obstacle_distance))
