from pymavlink import mavutil
import time

# Connection string to the vehicle. For example, "udp:127.0.0.1:14550".
connection_string = "udp:127.0.0.1:14550"

# Connect to the vehicle
vehicle = mavutil.mavlink_connection(connection_string)

# Wait for the heartbeat to ensure a connection has been established
while True:
    msg = vehicle.recv_match(type='HEARTBEAT', blocking=True)
    if msg:
        break
    time.sleep(1)

# Arm the vehicle
vehicle.mav.command_long_send(
    vehicle.target_system, vehicle.target_component,
    mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 0,
    1, 0, 0, 0, 0, 0, 0
)

# Take off to 2 meters altitude
target_altitude = 2.0  # meters
vehicle.mav.command_long_send(
    vehicle.target_system, vehicle.target_component,
    mavutil.mavlink.MAV_CMD_NAV_TAKEOFF, 0,
    0, 0, 0, 0, 0, 0, 0, target_altitude
)

# Wait for the vehicle to reach the target altitude
while True:
    msg = vehicle.recv_match(type='GLOBAL_POSITION_INT', blocking=True)
    current_altitude = msg.alt / 1000.0  # Convert from mm to meters
    print("Current altitude: {} meters".format(current_altitude))
    
    if current_altitude >= target_altitude * 0.95:  # 95% of target altitude
        print("Reached target altitude!")
        break

    time.sleep(1)

# Do other tasks or maneuvers here

# Disarm the vehicle
vehicle.mav.command_long_send(
    vehicle.target_system, vehicle.target_component,
    mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 0,
    0, 0, 0, 0, 0, 0, 0
)

# Close the connection
vehicle.close()
