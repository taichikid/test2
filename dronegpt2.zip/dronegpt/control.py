from pymavlink import mavutil
import time
import get_obstacle_distance
import move_forward
import perform_avoidance
import set_land_mode

# Connection string to the vehicle. For example, "udp:127.0.0.1:14550".
connection_string = "udp:127.0.0.1:14550"

# Connect to the vehicle
vehicle = mavutil.mavlink_connection(connection_string)

# Wait for the heartbeat to ensure a connection has been established
while True:
    msg = vehicle.recv_match(type='HEARTBEAT', blocking=True)
    if msg:
        break
    time.sleep(1)

# Arm the vehicle
vehicle.mav.command_long_send(
    vehicle.target_system, vehicle.target_component,
    mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 0,
    1, 0, 0, 0, 0, 0, 0
)

# Take off to 2 meters altitude
target_altitude = 2.0  # meters
vehicle.mav.command_long_send(
    vehicle.target_system, vehicle.target_component,
    mavutil.mavlink.MAV_CMD_NAV_TAKEOFF, 0,
    0, 0, 0, 0, 0, 0, 0, target_altitude
)

# Wait for the vehicle to reach the target altitude
while True:
    msg = vehicle.recv_match(type='GLOBAL_POSITION_INT', blocking=True)
    current_altitude = msg.alt / 1000.0  # Convert from mm to meters
    print("Current altitude: {} meters".format(current_altitude))
    
    if current_altitude >= target_altitude * 0.95:  # 95% of target altitude
        print("Reached target altitude!")
        break

    time.sleep(1)

# Distance threshold for obstacle avoidance (in meters)
obstacle_threshold = 2.0

# Set the initial target location to move forward
target_location = (vehicle.location.global_frame.lat + 0.0001,
                   vehicle.location.global_frame.lon + 0.0001,
                   vehicle.location.global_frame.alt)

# Main loop
while True:
    # # Check distance to obstacle
    # obstacle_distance = get_obstacle_distance.get_obstacle_distance() # Replace with actual function
    # print("Obstacle distance: {} meters".format(obstacle_distance))

    # if obstacle_distance < obstacle_threshold:
    #     # Obstacle detected, perform avoidance maneuver (e.g., turn left)
    #     print("Obstacle detected! Performing avoidance maneuver.")
    #     perform_avoidance.perform_avoidance()

    if obstacle_distance < obstacle_threshold:
        set_land_mode.set_land_mode()

    # Move forward in the current direction
    move_forward.move_forward()

    time.sleep(1)  # Adjust the loop rate as needed
