from pymavlink import mavutil

def set_land_mode():
    # LANDモードへの切り替えを要求するMAVLinkメッセージの作成
    msg = master.mav.command_long_encode(
        1,  # システムID
        1,  # コンポーネントID
        mavutil.mavlink.MAV_CMD_NAV_LAND,  # LANDコマンド
        0,  # 自動モード切り替えを使用しない
        0,  # パラメータ1
        0,  # パラメータ2
        0,  # パラメータ3
        0,  # パラメータ4
        0,  # パラメータ5
        0,  # パラメータ6
        0   # パラメータ7
    )

    # MAVLinkメッセージを送信
    master.mav.send(msg)